import { bench, describe } from "vitest";
import p5 from "../../src/app";
import { WEBGL, WEBGPU } from "../../src/core/constants";
import rendererWebGPU from "../../src/webgpu/p5.RendererWebGPU";

const fontFile = "../../test/manual-test-examples/type/font/LiberationSans-Bold.ttf";

const strs = {
  single: "Performance",
  ten: "Performance testing 10 words at a time is exhaustive! Right?",
  paragraph: Array.from({ length: 10 }, (_, i) =>
    `${i === 0 ? "\t": ""}Performance is vital in all aspects of text rendering, even 10 lines at a time. This is line ${i + 1} of 10.`
  ).join("\n") // This will hit around 15fps, 21275 points
};

// Parameterizing test cases by function ensures consistency in test parameters across all renderers.
// Future tests should follow a similar format
const TO_POINTS_CASES = [
  {label: "textToPoints() single word", str: strs.single, textSize: 20, sampleFactor: 0.5, points: 317, variance: 5, render: false},
  {label: "textToPoints() single word, 150pt", str: strs.single, textSize: 150, sampleFactor: 0.5, points: 2336, variance: 50, render: false},
  {label: "textToPoints() single word, with render", str: strs.single, textSize: 20, sampleFactor: 0.5, points: 317, variance: 5, render: true},
  {label: "textToPoints() 10 words", str: strs.ten, textSize: 20, sampleFactor: 0.5, points: 1453, variance: 5, render: false},
  {label: "textToPoints() paragraph", str: strs.paragraph, textSize: 20, sampleFactor: 0.5, points: 21275, variance: 50, render: false},
];

// Expected number of contours for each TO_POINTS_CASES entry, in the same order.
// Contour count depends on the glyph outlines (not textSize or sampleFactor),
// so the same string gives the same count.
const EXPECTED_CONTOURS = [
  16,   // single word
  16,   // single word, 150pt
  16,   // single word, with render
  76,   // 10 words
  1167, // paragraph
];

const TO_CONTOURS_CASES = TO_POINTS_CASES.map((c, i) => ({
  ...c,
  label: c.label.replace("textToPoints()", "textToContours()"),
  contours: EXPECTED_CONTOURS[i],
}));

const TO_MODEL_CASES = [
  {label: "textToModel() single word", str: strs.single, textSize: 20, sampleFactor: 0.5, render: false},
  {label: "textToModel() single word, 150pt", str: strs.single, textSize: 150, sampleFactor: 0.5, render: false},
  {label: "textToModel() single word, with render", str: strs.single, textSize: 20, sampleFactor: 0.5, render: true},
  {label: "textToModel() 10 words", str: strs.ten, textSize: 20, sampleFactor: 0.5, render: false},
  {label: "textToModel() paragraph", str: strs.paragraph, textSize: 20, sampleFactor: 0.5, render: false},
];

async function bootstrap(w = 400, h = 400, renderer = undefined) {
  var myp5;
  var font;

  new p5(function (p) {
    p.setup = async function () {
      myp5 = p;
      font = await p.loadFont(fontFile);
      if (renderer === WEBGPU) {
        await p.createCanvas(w, h, renderer);
      } else {
        p.createCanvas(w, h, renderer);
      }
    };
  });
  await vi.waitFor(() => {
    if (myp5 === undefined || font === undefined) throw new Error("not ready");
  });
  return { myp5, font };
}

function drawPoints(myp5, points) {
    for (let point of points) {
      myp5.point(point.x, point.y);
    }
}

function drawContours(myp5, contours) {
  for (let contour of contours) {
    myp5.beginShape();
    for (let pt of contour) {
      myp5.vertex(pt.x, pt.y);
    }
    myp5.endShape(myp5.CLOSE);
  }
}

const options = { iterations: 20, time: 500 };

describe("Typography: bench 2D", function() {
  var myp5, font;

  for (let testCase of TO_POINTS_CASES) {
    bench(
      testCase.label,
      async () => {
        const points = font.textToPoints(testCase.str, 10, 20, { sampleFactor: testCase.sampleFactor });
        assert.closeTo(points.length, testCase.points, testCase.variance);
        if (testCase.render) {
          drawPoints(myp5, points);
        }
      },
      {
        ...options,
        setup: async () => {
          ({myp5, font} = await bootstrap());
          myp5.textSize(testCase.textSize);
        },
        teardown: () => myp5.remove()
      }
    );
  }

  for (let testCase of TO_CONTOURS_CASES) {
    bench(
      testCase.label,
      async () => {
        const contours = font.textToContours(testCase.str, 10, 20, { sampleFactor: testCase.sampleFactor });
        assert.equal(contours.length, testCase.contours);
        const total = contours.reduce((n, c) => n + c.length, 0);
        assert.closeTo(total, testCase.points, testCase.variance);
        if (testCase.render) {
          drawContours(myp5, contours);
        }
      },
      {
        ...options,
        setup: async () => {
          ({myp5, font} = await bootstrap());
          myp5.textSize(testCase.textSize);
        },
        teardown: () => myp5.remove()
      }
    );
  }

});

describe("Typography: bench WebGL", function() {
  var myp5, font;

  for (let testCase of TO_POINTS_CASES) {
    bench(
      testCase.label,
      async () => {
        const points = font.textToPoints(testCase.str, 10, 20, { sampleFactor: testCase.sampleFactor });
        assert.closeTo(points.length, testCase.points, testCase.variance);
        if (testCase.render) {
          drawPoints(myp5, points);
        }
      },
      {
        ...options,
        setup: async () => {
          ({myp5, font} = await bootstrap(400, 400, WEBGL));
          myp5.textSize(testCase.textSize);
        },
        teardown: () => myp5.remove()
      }
    );
  }

  for (let testCase of TO_CONTOURS_CASES) {
    bench(
      testCase.label,
      async () => {
        const contours = font.textToContours(testCase.str, 10, 20, { sampleFactor: testCase.sampleFactor });
        assert.equal(contours.length, testCase.contours);
        const total = contours.reduce((n, c) => n + c.length, 0);
        assert.closeTo(total, testCase.points, testCase.variance);
        if (testCase.render) {
          drawContours(myp5, contours);
        }
      },
      {
        ...options,
        setup: async () => {
          ({myp5, font} = await bootstrap(400, 400, WEBGL));
          myp5.textSize(testCase.textSize);
        },
        teardown: () => myp5.remove()
      }
    );
  }

  for (let testCase of TO_MODEL_CASES) {
    bench(
      testCase.label,
      async () => {
        const model = font.textToModel(testCase.str, 10, 20, { sampleFactor: testCase.sampleFactor });
        assert.isAbove(model.vertices.length, 0);
        if (testCase.render) {
          myp5.model(model);
        }
      },
      {
        ...options,
        setup: async () => {
          ({myp5, font} = await bootstrap(400, 400, WEBGL));
          myp5.textSize(testCase.textSize);
        },
        teardown: () => myp5.remove()
      }
    );
  }

});

describe("Typography: bench WebGPU", function() {
  p5.registerAddon(rendererWebGPU);
  var myp5, font;

  for (let testCase of TO_POINTS_CASES) {
    bench(
      testCase.label,
      async () => {
        const points = font.textToPoints(testCase.str, 10, 20, { sampleFactor: testCase.sampleFactor });
        assert.closeTo(points.length, testCase.points, testCase.variance);
        if (testCase.render) {
          drawPoints(myp5, points);
        }
      },
      {
        ...options,
        setup: async () => {
          ({myp5, font} = await bootstrap(400, 400, WEBGPU));
          myp5.textSize(testCase.textSize);
        },
        teardown: () => myp5.remove()
      }
    );
  }

  for (let testCase of TO_CONTOURS_CASES) {
    bench(
      testCase.label,
      async () => {
        const contours = font.textToContours(testCase.str, 10, 20, { sampleFactor: testCase.sampleFactor });
        assert.equal(contours.length, testCase.contours);
        const total = contours.reduce((n, c) => n + c.length, 0);
        assert.closeTo(total, testCase.points, testCase.variance);
        if (testCase.render) {
          drawContours(myp5, contours);
        }
      },
      {
        ...options,
        setup: async () => {
          ({myp5, font} = await bootstrap(400, 400, WEBGPU));
          myp5.textSize(testCase.textSize);
        },
        teardown: () => myp5.remove()
      }
    );
  }

  for (let testCase of TO_MODEL_CASES) {
    bench(
      testCase.label,
      async () => {
        const model = font.textToModel(testCase.str, 10, 20, { sampleFactor: testCase.sampleFactor });
        assert.isAbove(model.vertices.length, 0);
        if (testCase.render) {
          myp5.model(model);
        }
      },
      {
        ...options,
        setup: async () => {
          ({myp5, font} = await bootstrap(400, 400, WEBGPU));
          myp5.textSize(testCase.textSize);
        },
        teardown: () => myp5.remove()
      }
    );
  }

});