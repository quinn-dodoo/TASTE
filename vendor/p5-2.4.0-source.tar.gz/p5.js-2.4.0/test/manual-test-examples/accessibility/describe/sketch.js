function setup() {
  // Uncomment any of the following lines to test
  
  createCanvas(400, 400);

  // Text only (fallback is the default)
  // describe('Cái này là bài thi');

  // Text and display
  // describe('Esto es una prueba', LABEL);

  // Text and lang
  //describe('Esto es una prueba', 'es');

  // Text, display, and lang
  // describe('Cái này là bài thi', LABEL, 'vi');

  // Text and lang
  // describe('यह टेस्ट है', 'hi');



  // Name and text only (fallback is the default)
  // describeElement('a', 'Cái này là bài thi');

  // Name, text, and display
  // describeElement('b', 'Esto es una prueba', LABEL);

  // Name, text, and lang
  // describeElement('c', 'Esto es una prueba', 'es');

  // Name, text, display, and lang
  // describeElement('d', 'Cái này là bài thi', LABEL, 'vi');

  // Name, text, and lang
  // describeElement('e', 'यह टेस्ट है', 'hi');

  fill('blue');
  circle(200, 150, 100);
}